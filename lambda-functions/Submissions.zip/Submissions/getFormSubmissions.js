/**
 * Query Salesforce with proper error handling and URL construction
 */
async function querySalesforce(instanceUrl, token, soql) {
  try {
    // Ensure instanceUrl has https protocol
    const baseUrl = instanceUrl.startsWith("https://")
      ? instanceUrl
      : `https://${instanceUrl}`;
    const encodedQuery = encodeURIComponent(soql);
    const url = `${baseUrl}/services/data/v60.0/query?q=${encodedQuery}`;

    console.log(`Executing SOQL: ${soql}`);

    const response = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(
        errorData.error || `Salesforce query failed: ${response.status}`
      );
    }

    return await response.json();
  } catch (error) {
    console.error(`Salesforce query failed: ${error.message}`);
    throw error;
  }
}

/**
 * Get access token for Salesforce API calls
 */
async function getAccessToken(userId, instanceUrl) {
  try {
    const tokenUrl =
      process.env.GET_ACCESS_TOKEN_URL ||
      "https://76vlfwtmig.execute-api.us-east-1.amazonaws.com/prod/getAccessToken";

    const response = await fetch(tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId, instanceUrl }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(
        errorData.error || `Failed to fetch access token: ${response.status}`
      );
    }

    const data = await response.json();

    if (!data.access_token) {
      throw new Error("No access token returned from authentication service");
    }

    return data.access_token;
  } catch (error) {
    console.error(`Failed to get access token: ${error.message}`);
    throw new Error(`Authentication failed: ${error.message}`);
  }
}

/**
 * Update submission status in Salesforce
 */
async function updateSubmissionStatus(
  instanceUrl,
  token,
  submissionId,
  status
) {
  try {
    const baseUrl = instanceUrl.startsWith("https://")
      ? instanceUrl
      : `https://${instanceUrl}`;

    const url = `${baseUrl}/services/data/v60.0/sobjects/Submission__c/${submissionId}`;

    const response = await fetch(url, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        Status__c: status,
      }),
    });

    if (response.ok) {
      console.log(
        `Successfully updated submission status: ${submissionId} to ${status}`
      );
      return { success: true };
    } else {
      const errorData = await response.json();
      console.error(
        `Failed to update submission status ${submissionId}:`,
        errorData
      );
      return {
        success: false,
        error: errorData.message || `Update failed: ${response.status}`,
      };
    }
  } catch (error) {
    console.error(`Error updating submission status ${submissionId}:`, error);
    return { success: false, error: error.message };
  }
}

/**
 * Delete files from AWS S3
 */
async function deleteFilesFromAWS(fileUrls) {
  try {
    console.log(`Deleting ${fileUrls.length} files from AWS:`, fileUrls);

    // Import AWS SDK (you'll need to add this to your lambda dependencies)
    const { S3Client, DeleteObjectCommand } = require("@aws-sdk/client-s3");

    const s3Client = new S3Client({ region: "us-east-1" });
    const bucketName = "quickform-images";

    const deleteResults = [];

    for (const fileUrl of fileUrls) {
      try {
        // Extract the key from the S3 URL
        // URL format: https://quickform-images.s3.us-east-1.amazonaws.com/1234567890_filename.ext
        const urlParts = fileUrl.split("/");
        const key = urlParts[urlParts.length - 1]; // Get the last part (filename with timestamp)

        if (!key || key === fileUrl) {
          // If we can't extract a proper key, skip this file
          deleteResults.push({
            url: fileUrl,
            success: false,
            error: "Could not extract S3 key from URL",
          });
          continue;
        }

        const deleteParams = {
          Bucket: bucketName,
          Key: key,
        };

        const deleteCommand = new DeleteObjectCommand(deleteParams);
        await s3Client.send(deleteCommand);

        deleteResults.push({
          url: fileUrl,
          success: true,
          message: `Successfully deleted ${key} from S3`,
        });

        console.log(`Successfully deleted file: ${key}`);
      } catch (fileError) {
        console.error(`Error deleting file ${fileUrl}:`, fileError);
        deleteResults.push({
          url: fileUrl,
          success: false,
          error: fileError.message,
        });
      }
    }

    return deleteResults;
  } catch (error) {
    console.error("Error in deleteFilesFromAWS:", error);
    return fileUrls.map((url) => ({
      url,
      success: false,
      error: error.message,
    }));
  }
}

/**
 * Delete submissions from Salesforce
 */
async function deleteSubmissions(instanceUrl, token, submissionIds) {
  try {
    const baseUrl = instanceUrl.startsWith("https://")
      ? instanceUrl
      : `https://${instanceUrl}`;
    const deleteResults = [];

    console.log(`Deleting ${submissionIds.length} submissions`);

    // Delete submissions one by one (Salesforce doesn't support bulk delete via REST API easily)
    for (const submissionId of submissionIds) {
      try {
        const url = `${baseUrl}/services/data/v60.0/sobjects/Submission__c/${submissionId}`;

        const response = await fetch(url, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (response.ok) {
          deleteResults.push({ id: submissionId, success: true });
          console.log(`Successfully deleted submission: ${submissionId}`);
        } else {
          const errorData = await response.json();
          deleteResults.push({
            id: submissionId,
            success: false,
            error: errorData.message || `Delete failed: ${response.status}`,
          });
          console.error(
            `Failed to delete submission ${submissionId}:`,
            errorData
          );
        }
      } catch (error) {
        deleteResults.push({
          id: submissionId,
          success: false,
          error: error.message,
        });
        console.error(`Error deleting submission ${submissionId}:`, error);
      }
    }

    return deleteResults;
  } catch (error) {
    console.error(`Delete operation failed: ${error.message}`);
    throw error;
  }
}

/**
 * Main Lambda handler
 */
export const handler = async (event) => {
  console.log("Event received:", JSON.stringify(event, null, 2));

  // Handle CORS preflight requests
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
      },
      body: "",
    };
  }

  try {
    // Parse request body
    let requestBody;
    try {
      requestBody =
        typeof event.body === "string"
          ? JSON.parse(event.body)
          : event.body || {};
    } catch (parseError) {
      console.error("Failed to parse request body:", parseError.message);
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        body: JSON.stringify({ error: "Invalid JSON in request body" }),
      };
    }

    const { userId, instanceUrl, formVersionId, formId, accessToken } =
      requestBody;

    // Support both formId and formVersionId for backward compatibility
    const targetFormVersionId = formVersionId;
    const targetFormId = formId;

    // Validate required parameters
    if (!userId || !instanceUrl || (!targetFormVersionId && !targetFormId)) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        body: JSON.stringify({
          error: "Missing required parameters",
          required: ["userId", "instanceUrl", "formVersionId or formId"],
          received: {
            userId: !!userId,
            instanceUrl: !!instanceUrl,
            formVersionId: !!targetFormVersionId,
            formId: !!targetFormId,
          },
        }),
      };
    }

    // Get access token (use provided token or fetch new one)
    let token = accessToken;
    if (!token) {
      console.log("No access token provided, fetching new one...");
      token = await getAccessToken(userId, instanceUrl);
    }

    // Handle PATCH operation (update submission status)
    if (event.httpMethod === "PATCH") {
      const { submissionId, status } = requestBody;

      if (!submissionId || !status) {
        return {
          statusCode: 400,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
          },
          body: JSON.stringify({
            error: "Missing required parameters",
            required: ["submissionId", "status"],
          }),
        };
      }

      const updateResult = await updateSubmissionStatus(
        instanceUrl,
        token,
        submissionId,
        status
      );

      return {
        statusCode: updateResult.success ? 200 : 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
        },
        body: JSON.stringify(updateResult),
      };
    }

    // Handle DELETE operation
    if (event.httpMethod === "DELETE") {
      const { submissionIds } = requestBody;

      if (
        !submissionIds ||
        !Array.isArray(submissionIds) ||
        submissionIds.length === 0
      ) {
        return {
          statusCode: 400,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
          },
          body: JSON.stringify({
            error: "Missing or invalid submissionIds array",
            required: "submissionIds (array of submission IDs)",
          }),
        };
      }

      console.log(`Deleting submissions: ${submissionIds.join(", ")}`);

      // First, collect all file URLs from submissions that will be deleted
      const submissionsToDelete = submissions.filter((sub) =>
        submissionIds.includes(sub.id)
      );
      const fileUrls = [];

      submissionsToDelete.forEach((sub) => {
        Object.values(sub.data || {}).forEach((value) => {
          if (typeof value === "string") {
            // Check if it's an S3 URL from our quickform-images bucket
            if (
              value.includes("quickform-images.s3.") ||
              value.includes("quickform-images.s3-") ||
              (value.startsWith("https://") &&
                value.includes("amazonaws.com") &&
                value.includes("quickform"))
            ) {
              fileUrls.push(value);
            }
          } else if (Array.isArray(value)) {
            // Handle arrays of file URLs (for multiple file uploads)
            value.forEach((item) => {
              if (
                typeof item === "string" &&
                (item.includes("quickform-images.s3.") ||
                  item.includes("quickform-images.s3-") ||
                  (item.startsWith("https://") &&
                    item.includes("amazonaws.com") &&
                    item.includes("quickform")))
              ) {
                fileUrls.push(item);
              }
            });
          }
        });
      });

      // Delete files from AWS if any exist
      if (fileUrls.length > 0) {
        console.log(`Found ${fileUrls.length} files to delete from AWS`);
        await deleteFilesFromAWS(fileUrls);
      }

      const deleteResults = await deleteSubmissions(
        instanceUrl,
        token,
        submissionIds
      );
      const successCount = deleteResults.filter(
        (result) => result.success
      ).length;
      const failureCount = deleteResults.length - successCount;

      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type,Authorization",
          "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
        },
        body: JSON.stringify({
          success: true,
          message: `Deleted ${successCount} of ${deleteResults.length} submissions`,
          results: deleteResults,
          filesDeleted: fileUrls.length,
          summary: {
            total: deleteResults.length,
            successful: successCount,
            failed: failureCount,
          },
        }),
      };
    }

    let actualFormVersionId = targetFormVersionId;
    let formVersions = [];

    // If formId is provided, fetch all versions and determine which one to use
    if (targetFormId) {
      console.log(`Fetching form versions for form: ${targetFormId}`);

      const versionsSoql = `
        SELECT Id, Name, Version__c, Stage__c, Form__c, CreatedDate
        FROM Form_Version__c 
        WHERE Form__c = '${targetFormId}' 
        ORDER BY Version__c DESC
      `;

      const versionsResponse = await querySalesforce(
        instanceUrl,
        token,
        versionsSoql
      );
      formVersions = versionsResponse.records || [];

      if (formVersions.length === 0) {
        throw new Error(`No form versions found for form: ${targetFormId}`);
      }

      // Find the current published version or latest non-draft version
      const publishedVersions = formVersions.filter(
        (v) => v.Stage__c === "Publish"
      );

      if (publishedVersions.length > 0) {
        // Use the latest published version
        actualFormVersionId = publishedVersions[0].Id;
      } else {
        // If no published versions, use the latest version
        actualFormVersionId = formVersions[0].Id;
      }

      console.log(
        `Using form version: ${actualFormVersionId} for form: ${targetFormId}`
      );
    } else if (targetFormVersionId) {
      // If only formVersionId is provided, we still need to get the form versions for the dropdown
      // First get the form ID from the form version
      const formVersionSoql = `
        SELECT Id, Form__c 
        FROM Form_Version__c 
        WHERE Id = '${targetFormVersionId}'
      `;

      const formVersionResponse = await querySalesforce(
        instanceUrl,
        token,
        formVersionSoql
      );
      if (
        formVersionResponse.records &&
        formVersionResponse.records.length > 0
      ) {
        const formId = formVersionResponse.records[0].Form__c;

        // Now get all versions for this form
        const versionsSoql = `
          SELECT Id, Name, Version__c, Stage__c, Form__c, CreatedDate
          FROM Form_Version__c 
          WHERE Form__c = '${formId}' 
          ORDER BY Version__c DESC
        `;

        const versionsResponse = await querySalesforce(
          instanceUrl,
          token,
          versionsSoql
        );
        formVersions = versionsResponse.records || [];
      }

      actualFormVersionId = targetFormVersionId;
    }

    console.log(
      `Fetching submissions for form version: ${actualFormVersionId}`
    );

    // Fetch form fields to create field mapping
    const fieldsSoql = `
      SELECT Id, Name, Field_Type__c, Properties__c, Unique_Key__c, Order_Number__c 
      FROM Form_Field__c 
      WHERE Form_Version__c = '${actualFormVersionId}' 
      ORDER BY Order_Number__c ASC NULLS LAST, Name ASC
    `;

    const fieldsResponse = await querySalesforce(
      instanceUrl,
      token,
      fieldsSoql
    );

    const fieldRecords = fieldsResponse.records || [];
    console.log(`Found ${fieldRecords.length} form fields`);

    // Create fields mapping with all fields (no filtering for preview functionality)
    const fieldsMap = {};
    const allFieldsMap = {}; // For preview modal

    if (fieldRecords.length > 0) {
      console.log(`Found ${fieldRecords.length} total fields`);

      fieldRecords.forEach((field) => {
        let fieldLabel = field.Name;
        let fieldType = field.Field_Type__c;

        // Try to extract label and type from Properties__c if available
        if (field.Properties__c) {
          try {
            const properties = JSON.parse(field.Properties__c);
            if (properties.label) {
              fieldLabel = properties.label;
            }
            if (properties.type) {
              fieldType = properties.type;
            }
          } catch (parseError) {
            console.warn(
              `Failed to parse Properties__c for field ${field.Id}: ${parseError.message}`
            );
          }
        }

        // Use the actual field Id as the key
        const fieldKey = field.Id;
        const fieldInfo = {
          label: fieldLabel || `Field_${field.Id}`,
          type: fieldType,
          properties: field.Properties__c,
          orderNumber: field.Order_Number__c,
        };

        // Add to all fields map for preview
        allFieldsMap[fieldKey] = fieldInfo;

        // Add to display fields map (exclude static fields for table display)
        const staticFieldTypes = [
          "heading",
          "displaytext",
          "divider",
          "pagebreak",
          "formcalculation",
        ];
        const isStaticField =
          fieldType && staticFieldTypes.includes(fieldType.toLowerCase());

        if (!isStaticField) {
          fieldsMap[fieldKey] = fieldInfo.label;
        }
      });
    } else {
      console.log("No form fields found for this form version");
    }

    // Fetch submissions
    const submissionsSoql = `
      SELECT Id, Name, CreatedDate, LastModifiedDate, Submission_Data__c, Status__c 
      FROM Submission__c 
      WHERE Form_Version__c = '${actualFormVersionId}' 
      ORDER BY CreatedDate DESC
    `;

    const submissionsResponse = await querySalesforce(
      instanceUrl,
      token,
      submissionsSoql
    );

    const submissionRecords = submissionsResponse.records || [];
    console.log(`Found ${submissionRecords.length} submissions`);

    // Process submissions data
    const submissions = submissionRecords.map((sub, index) => {
      let parsedData = {};

      if (sub.Submission_Data__c) {
        try {
          parsedData = JSON.parse(sub.Submission_Data__c);
        } catch (parseError) {
          console.error(
            `Failed to parse Submission_Data__c for ${sub.Id}: ${parseError.message}`
          );
          // Keep empty object as fallback
        }
      }

      return {
        id: sub.Id,
        name: sub.Name || `Submission ${index + 1}`,
        submissionDate: sub.CreatedDate,
        lastModified: sub.LastModifiedDate,
        status: sub.Status__c || "Unread",
        data: parsedData,
        index: index + 1,
      };
    });

    // Handle case when no submissions are found
    if (submissions.length === 0) {
      console.log(
        `No submissions found for form version: ${actualFormVersionId}`
      );
    }

    // Return successful response
    const response = {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
      },
      body: JSON.stringify({
        success: true,
        submissions,
        fields: fieldsMap,
        allFields: allFieldsMap,
        formVersions: formVersions.map((v) => ({
          id: v.Id,
          name: v.Name,
          version: v.Version__c,
          stage: v.Stage__c,
          createdDate: v.CreatedDate,
        })),
        metadata: {
          totalCount: submissions.length,
          formVersionId: actualFormVersionId,
          formId: targetFormId,
          fetchedAt: new Date().toISOString(),
        },
      }),
    };

    console.log(`Successfully returned ${submissions.length} submissions`);
    return response;
  } catch (error) {
    console.error("Lambda execution error:", error);

    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
      },
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message,
        timestamp: new Date().toISOString(),
      }),
    };
  }
};

// Test function for local development (uncomment to test locally)
/*
async function testLocally() {
  const testEvent = {
    httpMethod: 'POST',
    body: JSON.stringify({
      userId: 'your-test-user-id',
      instanceUrl: 'your-salesforce-instance.salesforce.com',
      formVersionId: 'your-test-form-version-id'
    })
  };
  
  try {
    const result = await handler(testEvent);
    console.log('Test result:', JSON.stringify(result, null, 2));
  } catch (error) {
    console.error('Test error:', error);
  }
}

// Uncomment the line below to run local test
// testLocally();
*/
